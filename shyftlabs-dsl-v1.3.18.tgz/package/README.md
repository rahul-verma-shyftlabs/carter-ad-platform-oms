# @shyftlabs-dsl/dsl-lib

Design System Library for Carter/Shyftlabs Dashboards with Storybook and Shadcn UI Library and Tailwind

## Installation

```bash
npm install @shyftlabs-dsl/dsl-lib
# or
yarn add @shyftlabs-dsl/dsl-lib
```

## Run/Build the application

- Install Dependencies & Initial Pre Commit Hooks (Note: We use yarn as a package manager so please install yarn before proceeding)

```bash
yarn
yarn run prepare
npx husky add .husky/pre-commit "yarn run husky"
```

- Run the development server:

```bash
yarn dev
```

- Run the Storybook server:

```bash
yarn storybook
```

- Build the package:

```bash
yarn build
```

- Build Storybook:

```bash
yarn build-storybook
```

## Deploying to GitHub Pages

This project is configured to deploy Storybook to GitHub Pages automatically.

### Automatic Deployment

The project includes a GitHub Actions workflow (`.github/workflows/deploy-gh-pages.yml`) that automatically deploys Storybook to GitHub Pages when you push to `main` or `master` branch.

**To enable GitHub Pages:**
1. Go to your repository Settings → Pages
2. Under "Source", select "GitHub Actions"
3. The workflow will automatically deploy on the next push to `main`/`master`

### Manual Deployment

You can also deploy manually using the deploy script:

```bash
# Build and deploy Storybook to GitHub Pages
yarn deploy:storybook

# Or deploy an already built Storybook
yarn deploy
```

The Storybook will be available at: `https://<username>.github.io/<repository-name>/`

## Publishing to NPM

This package is published to npm as `@shyftlabs-dsl/dsl-lib`.

### Publishing

To publish a new version:

1. Update the version in `package.json`
2. Build the package: `yarn build`
3. Publish to npm: `npm publish --access public`

The package is configured to publish to the public npm registry at `https://registry.npmjs.org/`.
